# 2D videogame created using the engine given in the course of Electronic Games from Universitat Pompeu Fabra.

Name: Jinsong Liu
Email: jinsong.liu01@estudiant.upf.edu
NIA: 254748
Link to YouTube video: https://youtu.be/TvSFJqqJbMQ

The snore sound will start whenever killCount reaches a multiple of 10, except 0.
The clock sound will start whenever the player gets hit.

There are 3 endings depending on the final killCount score:
- killCount < 120
- 120 <= killCount < 240
- 240 <= killCount 

The basic controls are:
- Arrow keys to move
- Z to roll and dodge
- X to fire projectile

Additional controls:
- J to add 1 enemy to the field
- K to set player's lives to 0
- L to add 120 to player's kill count

# Resources:
## Sprites and tilesets
Player and enemy: https://www.spriters-resource.com/pc_computer/enterthegungeon/sheet/156859/
Tileset: https://anokolisa.itch.io/dungeon-crawler-pixel-art-asset-pack
Clouds and backgrounds set: https://free-game-assets.itch.io/free-sky-with-clouds-background-pixel-art-set
Bullets and particles: https://bdragon1727.itch.io/free-effect-and-bullet-16x16

## Sounds and music:
8 bit moonlight sonata 1st movement: https://youtu.be/zC51MHt-eGQ
moonlight sonata 3rd movement: https://youtu.be/EhDtCYkCrlU
projectile firing sfx: https://youtu.be/qWOM7vkDATo
getting hit clock sfx: https://youtu.be/o5jaeEUbpFc
dodging sfx: https://youtu.be/9UFXKKh6A1o
snoring sfx: https://youtu.be/dNr7nXvntO8
ending1 alarm: https://youtu.be/PWn-Wh9O3N8
ending1 song: https://youtu.be/yebh32JSs9g
ending1 scream: https://youtu.be/HtCQQmBdJ8I
ending2 song: https://youtu.be/Q2Q7JlekyN8